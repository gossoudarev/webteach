var PORT = 8888;
var express = require('express'),
	app = express(),
    http = require('http').Server(app),
    io = require('socket.io')(http);

module.exports = (function(){
   function inner(){
      this.start = function (whatToDo){
          app.use(express.static(__dirname + '/public')); 
		   
		  app.get('/page', function(req, res){
			  res.send('<h1>Hey it works!</h1>');
		  });
		  
		  io.on('connection', function(socket){
		  		      console.log('a user connected!');
					  
				      socket.broadcast.emit('chat message push', '>> a user connected '); //everyone except the new one
				      socket.emit('chat message push', 'Welcome to Ilia Goss chat!'); //only the newcomer

				      //message from client - recast to others
				      socket.on('chat message', function(msg){
				            console.log('message: ' + msg);
				            socket.broadcast.emit('chat message push', msg);
				            socket.emit('chat message push', '<strong>me:</strong> ' + msg );
				      });
				      socket.on('disconnect', function(){
				         console.log('a user disconnected!');
				         socket.broadcast.emit('chat message push', '>> a user disconnected ');
				      });					  
		  });
		  
		  app.get('/chat', function(req, res){ 
			  res.redirect('/client.html');
			  
		  }); 
		   
		  http.listen(process.env.port || PORT, function(){
			  console.log(PORT);
		  });  
      };   
    }
  return new inner;
})();