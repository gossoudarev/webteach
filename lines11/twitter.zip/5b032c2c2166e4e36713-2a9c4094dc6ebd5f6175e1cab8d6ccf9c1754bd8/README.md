## require-from-twitter

Since Twitter doesn't have an edit button, it's a suitable host for JavaScript modules.

### How to use

Source tweet: https://twitter.com/rauchg/status/712799807073419264

```js
const leftPad = await requireFromTwitter('712799807073419264');
console.log(leftPad(1, 5));      // '00001'
console.log(leftPad(1234, 5));   // '01234'
console.log(leftPad(12345, 5));  // '12345'
```

### Running this example

```bash
# populate `twitter-config.json` with your API tokens
$ npm install
$ npm test
```