import { babel } from './package';
import { transform } from 'babel-core';
import { decodeHTML as decode } from 'entities';
import Twit from 'twit';

// edit twitter-config.json first
const twit = new Twit(require('./twitter-config'));

export default async function requireFromTwitter (id) {
  const tweet = await twit.get(`/statuses/show/:id`, { id });
  if (tweet.errors) throw new Error(`Cannot find module '${id}'`);
  const { text } = tweet.data;
  const exports = {};
  eval(transform(decode(text), babel).code);
  return exports.default;
}