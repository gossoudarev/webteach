import requireFromTwitter from './';

requireFromTwitter('712799807073419264')
.then((leftPad) => {
  console.log(leftPad(1, 5));
  console.log(leftPad(1234, 5));
  console.log(leftPad(12345, 5));
}, (err) => console.error(err.stack));