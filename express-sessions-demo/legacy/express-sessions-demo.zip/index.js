require('./server-4-post').start(result=>
	result?console.log(result):console.log('started')
);

// ajax
//server-4-xget
//server-4-xpost
// non-ajax
//server-4-post
